const audio = {
    Map: new Howl({
        src: './audio/map.wav',
        html5: true
    })
}